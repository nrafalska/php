<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Event;
use App\Models\Venue;

class DatabaseSeeder extends Seeder
{
    public function run()
    {
        Venue::factory(20)->create()->each(function ($venue) {
            Event::factory(2)->create(['venue_id' => $venue->id]);
        });
    }
}
