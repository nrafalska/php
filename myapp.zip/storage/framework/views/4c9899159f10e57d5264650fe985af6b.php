

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Edit Event</h1>

        <form action="<?php echo e(route('events.update', $event->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo e($event->name); ?>" required>
            </div>

            <div class="form-group">
                <label for="poster">Poster:</label>
                <input type="file" class="form-control" id="poster" name="poster">
                <?php if($event->poster): ?>
                    <img src="<?php echo e(asset('storage/' . $event->poster)); ?>" alt="Poster" style="width: 100px;">
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="event_date">Event Date:</label>
                <input type="date" class="form-control" id="event_date" name="event_date" value="<?php echo e($event->event_date); ?>" required>
            </div>

            <div class="form-group">
                <label for="venue_id">Venue:</label>
                <select class="form-control" id="venue_id" name="venue_id" required>
                    <?php $__currentLoopData = $venues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($venue->id); ?>" <?php echo e($venue->id == $event->venue_id ? 'selected' : ''); ?>>
                            <?php echo e($venue->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rumpelst\myapp\resources\views/events/edit.blade.php ENDPATH**/ ?>