

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Events</h1>
        <a href="<?php echo e(route('events.create')); ?>" class="btn btn-primary mb-3">Create New Event</a>

        <h2>Current Weather</h2>
        <p>Temperature: <?php echo e($weather['main']['temp']); ?>°C</p>
        <p>Weather: <?php echo e($weather['weather'][0]['description']); ?></p>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Poster</th>
                    <th>Date</th>
                    <th>Venue</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($event->name); ?></td>
                        <td>
                            <?php if($event->poster): ?>
                                <img src="<?php echo e(Storage::url($event->poster)); ?>" alt="Poster" style="width: 100px;">
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($event->event_date); ?></td>
                        <td><?php echo e($event->venue->name); ?></td>
                        <td>
                            <a href="<?php echo e(route('events.edit', $event->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                            <form action="<?php echo e(route('events.destroy', $event->id)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($events->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rumpelst\myapp\resources\views/events/index.blade.php ENDPATH**/ ?>