<?php

namespace App\Services;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

class OpenWeatherService
{
    protected $client;

    public function __construct()
    {
        $this->client = new Client([
            'base_uri' => 'https://api.openweathermap.org/data/2.5/',
        ]);
    }

    public function getWeather($lat, $lng)
    {
        try {
            $response = $this->client->get("weather", [
                'query' => [
                    'lat' => $lat,
                    'lon' => $lng,
                    'appid' => config('app.openweathermap_api_key'),
                    'units' => 'metric',
                ],
            ]);

            return json_decode($response->getBody(), true);
        } catch (RequestException $e) {
            if ($e->hasResponse()) {
                $statusCode = $e->getResponse()->getStatusCode();
                if ($statusCode == 401) {
                    throw new \Exception("API key is invalid");
                }
            }
            throw $e;
        }
    }
}
