<?php

namespace App\Services;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

class WeatherService
{
    protected $client;

    public function __construct()
    {
        $this->client = new Client([
            'base_uri' => 'https://api.stormglass.io/v2/',
            'headers' => [
                'Authorization' => env('STORMGLASS_API_KEY'),
            ],
        ]);
    }

    public function getWeather($lat, $lng)
    {
        try {
            $response = $this->client->get("weather/point", [
                'query' => [
                    'lat' => $lat,
                    'lng' => $lng,
                    'params' => 'airTemperature',
                ],
            ]);

            return json_decode($response->getBody(), true);
        } catch (RequestException $e) {
            if ($e->hasResponse()) {
                $statusCode = $e->getResponse()->getStatusCode();
                if ($statusCode == 403) {
                    throw new \Exception("API key is invalid");
                }
            }
            throw $e;
        }
    }
}
