<?php
namespace App\Http\Controllers;

use App\Models\Event; // переконайтеся, що це імпортовано
use App\Models\Venue;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use App\Services\OpenWeatherService;

class EventController extends Controller
{
    protected $weatherService;

    public function __construct(OpenWeatherService $weatherService)
    {
        $this->weatherService = $weatherService;
    }

    public function index()
    {
        $apiKey = config('app.openweathermap_api_key');
        Log::info('OpenWeatherMap API Key: ' . $apiKey);
    
        if (empty($apiKey)) {
            throw new \Exception("API key is missing or not set");
        }
    
        $latitude = 50.4501;
        $longitude = 30.5234;
    
        $weather = $this->weatherService->getWeather($latitude, $longitude);
    
        $events = Event::with('venue')->paginate(10);
    
        Log::info('Fetched events', ['events' => $events]);
    
        return view('events.index', compact('events', 'weather'));
    }
    

    public function create()
    {
        $venues = Venue::all();
        return view('events.create', compact('venues'));
    }

    public function store(Request $request)
{
    Log::info('Store method called');

    $request->validate([
        'name' => 'required|string|max:255',
        'poster' => 'required|image|max:2048',
        'event_date' => 'required|date',
        'venue_id' => 'required|exists:venues,id',
    ]);

    Log::info('Validating request', ['request' => $request->all()]);

    $posterPath = $request->file('poster')->store('posters', 'public');
    Log::info('Poster uploaded to: ' . $posterPath);

    $event = Event::create([
        'name' => $request->name,
        'poster' => $posterPath,
        'event_date' => $request->event_date,
        'venue_id' => $request->venue_id,
    ]);

    Log::info('Event created successfully', ['event' => $event]);

    return redirect()->route('events.index');
}


    public function edit(Event $event)
    {
        $venues = Venue::all();
        return view('events.edit', compact('event', 'venues'));
    }

    public function update(Request $request, Event $event)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'poster' => 'nullable|image|max:2048',
            'event_date' => 'required|date',
            'venue_id' => 'required|exists:venues,id',
        ]);

        if ($request->hasFile('poster')) {
            Storage::disk('public')->delete($event->poster);
            $posterPath = $request->file('poster')->store('posters', 'public');
            $event->poster = $posterPath;
        }

        $event->name = $request->name;
        $event->event_date = $request->event_date;
        $event->venue_id = $request->venue_id;
        $event->save();

        return redirect()->route('events.index');
    }

    public function destroy(Event $event)
    {
        Storage::disk('public')->delete($event->poster);
        $event->delete();

        return redirect()->route('events.index');
    }
}
