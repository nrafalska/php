@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Events</h1>
        <a href="{{ route('events.create') }}" class="btn btn-primary mb-3">Create New Event</a>

        <h2>Current Weather</h2>
        <p>Temperature: {{ $weather['main']['temp'] }}°C</p>
        <p>Weather: {{ $weather['weather'][0]['description'] }}</p>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Poster</th>
                    <th>Date</th>
                    <th>Venue</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($events as $event)
                    <tr>
                        <td>{{ $event->name }}</td>
                        <td>
                            @if($event->poster)
                                <img src="{{ Storage::url($event->poster) }}" alt="Poster" style="width: 100px;">
                            @endif
                        </td>
                        <td>{{ $event->event_date }}</td>
                        <td>{{ $event->venue->name }}</td>
                        <td>
                            <a href="{{ route('events.edit', $event->id) }}" class="btn btn-warning btn-sm">Edit</a>
                            <form action="{{ route('events.destroy', $event->id) }}" method="POST" style="display:inline-block;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        {{ $events->links() }}
    </div>
@endsection
